var array;
	var chaincode;
	var previousHash=0;
	var currentHash;
	var tx_val;
	var tx_date;
	var status;
	var id;
	var previousHashData;
	var devide;
	
	var travelRoute="Bhubaneswar";
	var currentHumidity="59%";
	var currentTemp="27°C|°F";
	var IoTId=1;
	
	
	

   $(document).ready(function () {
	
    array=new Array();
	$('#submitId').click(function() {

	//$("#blockChainviewId").show();
	//$("#blockChainaddId").hide();
	
	var requestor=$("#requestor").val();
	var transaction=$("#transactionType").val();
	var reciever=$("#reciever").val();
	
		previousHash=currentHash;
	if(previousHash==undefined){
		previousHash=0;
	}
	var bindingData=requestor+""+transaction+""+reciever;
	var validation=true;
	if(array.length>0){
	for(var a in array){
	if(array[a]==bindingData) {
		validation=false;
	}
	}
	}else{
	array.push(bindingData);
	}
	if(validation){
			
		 var requestURL="http://localhost:8082/test"
		$.ajax({
              type: "GET",
			  headers : {
			'Content-Type' : 'application/json'
			},
           
              url: requestURL+"/"+requestor+"/"+transaction+"/"+reciever+"/"+previousHash,
              success: function (data) {
			  
				//var origibalJson=JSON.stringify(data);
				var jsondata=JSON.stringify(data)
				var data1 = jQuery.parseJSON(jsondata);
			$.each(data1, function(key, item) 
				{
				chaincode=item.chaincode;
				//previousHash=item.previousHash;
				currentHash=item.currentHash;
				tx_val=item.tx_val;
				tx_date=item.tx_date;
				status=item.status;
				id=item.id;
			});
			
			if(reciever=='transporter'){
				var markup="<tr><td>"+id+"</td><td>"+requestor+"</td><td><a href='#' onclick=showTransactionWithIot('"+chaincode+"','"+requestor+"','"+transaction+"','"+reciever+"','"+currentHash+"','"+status+"')>"+tx_val+"</a></td><td>"+reciever+"</td><td>"+tx_date+"</td></tr>";
		
				$("#dataTable1").append(markup);
			
				
				
			}else{
				var markup="<tr><td>"+id+"</td><td>"+requestor+"</td><td><a href='#' onclick=showTransaction('"+chaincode+"','"+requestor+"','"+transaction+"','"+reciever+"','"+currentHash+"','"+status+"')>"+tx_val+"</a></td><td>"+reciever+"</td><td>"+tx_date+"</td></tr>";
				$("#dataTable1").append(markup);
			}
				
	
				
				
				 
				 $('#transactionModal').modal('toggle');
             },
             error: function (e) {
              
                 console.log("ERROR : ", e);
             }
          });
	}

      
    });
	
	$("#viewTransaction").click(function() {
		 $("#allTransactionId").html('');
		var markup;
		$("#viewTransactionModal").modal('show');
		
		 var requestURL="http://localhost:8082/retrieveAllTransaction"
		$.ajax({
              type: "GET",
              url: requestURL,
              success: function (data) {
			   var jsondata=JSON.stringify(data)
			   var data1 = jQuery.parseJSON(jsondata);
			$.each(data1, function(key, item) 
			{
				chaincode=item.chaincode;
				currentHash=item.currentHash;
				tx_val=item.tx_val;
				tx_date=item.tx_date;
				status=item.status;
				id=item.id;
				previousHashData=item.previousHash;
				devide="******************************************"
				 markup= "<tr><td style='font-size: 15px;font-family:bold'>ChainCode: "+chaincode+"</td></tr><tr ><td style='font-size: 15px;font-family:bold'>PreviousHash: "+previousHashData+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>CurrentHash: "+currentHash+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Transaction Value: "+tx_val+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Transaction Date: "+tx_date+"</td></tr><tr><td style='font-size: 15px;font-family:bold'>Status: "+status+"</td></tr><tr><td>"+devide+"</td></tr>";
				 $("#allTransactionId").append(markup);
			});
				
				
				 
				 //$('#').modal('toggle');
             },
             error: function (e) {
              
                 console.log("ERROR : ", e);
             }
          });
		
	});
	
	
	
   });
   
   function showTransaction(id,requestor,transactionVal,reciever,currentHash,status){
	    $("#iotDiv").hide();
	   $('#detailsTransactionModal').modal('show'); 
		$("#ChainCode").html(id);
		$("#requestorDet").html(requestor);
		$("#transaction").html(requestor+" "+transactionVal+" "+reciever);
		$("#recieverDet").html(reciever);
		$("#hashcode").html(currentHash);
		$("#transactionDate").html(tx_date);
	}
	
	  function showTransactionWithIot(id,requestor,transactionVal,reciever,currentHash,status){
		  $("#iotDiv").show();
	   $('#detailsTransactionModal').modal('show'); 
	   $("#ChainCode").html(id);
		$("#requestorDet").html(requestor);
		$("#transaction").html(requestor+" "+transactionVal+" "+reciever);
		$("#recieverDet").html(reciever);
		$("#hashcode").html(currentHash);
		$("#transactionDate").html(tx_date);
		$("#travelRoute").html(travelRoute);
		$("#currentHumidity").html(currentHumidity);
		$("#currentTemp").html(currentTemp);
		
	
	}