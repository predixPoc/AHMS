package com.techm.blockchain.BlockChainApp;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
@RestController
public class BlockChainRest {
	
	@Autowired
	
	private FmsRepository fmsRepository;
	
	@Autowired
	
	private FmsRegisterRepository fmsregisterRepository;
	
	/**
	 * @param requestor
	 * @param transaction
	 * @param reciever
	 * @return
	 */
	@RequestMapping(value = "/test/{requestor}/{transaction}/{reciever}/{previousHash}", method = RequestMethod.GET, produces = "application/json")
	public  @ResponseBody List<BlockDataBean>  test(@PathVariable("requestor") String requestor,@PathVariable("transaction") String transaction,@PathVariable("reciever") String reciever,@PathVariable("previousHash") String previousHash) {
		String originalVal=	requestor+" "+transaction+"  "+reciever;
		int priviousHasgval = Integer.parseInt(previousHash);
		List<BlockDataBean> existingTransactionval=new ArrayList<>();
		List<BlockDataBean> genesisTransaction1=new ArrayList<>();
		
		String[] genesisTransaction={originalVal};
		Block genesisBlock=new Block(priviousHasgval,genesisTransaction);
		System.out.println("Previous Hash   :  "+priviousHasgval);
		System.out.println("Current Hash   :  "+genesisBlock.getBlockhash());
		System.out.println("Transaction Value:   "+genesisTransaction[0]);
		
		
		String chainCode="FMS0001";
		String transactionTime;
		String status="Approved";
		
		DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd HH:mm:ss");
		Date date = new Date();
		System.out.println(dateFormat.format(date));
		transactionTime=dateFormat.format(date);
		
		
		String fisrtval="********************************************";
		String lastval="********************************************";
		
		String blockchainVal="/n/n"+"ChainCode:  "+chainCode+System.lineSeparator()+"PreviousHash= "+priviousHasgval+"/n"+"CurrentHash=  "+genesisBlock.getBlockhash()
		+"/n"+"Transaction:  "+genesisTransaction[0]+"/n"+"TransactionTime:"+transactionTime+"/n"+"Status=  "+status;
		
		System.out.println(blockchainVal);
		
		String finalval=System.lineSeparator()+fisrtval+System.lineSeparator()+blockchainVal+System.lineSeparator()+lastval;
		BlockDataBean bean=new BlockDataBean();
		bean.setChaincode("FMS0001");
		bean.setTx_date(transactionTime);
		bean.setTx_val(genesisTransaction[0]);
		bean.setCurrentHash(genesisBlock.getBlockhash());
		bean.setStatus("Approved");
		bean.setPreviousHash(priviousHasgval);
		fmsRepository.save(bean);
		genesisTransaction1=fmsRepository.findAll();
		System.out.println(genesisTransaction1.size()+"+++++++++++List is coming+++++++++++++++");
	
		return genesisTransaction1;
	}
	
	
	@RequestMapping(value = "/retrieveAllTransaction", method = RequestMethod.GET, produces = "application/json")
	public  @ResponseBody List<BlockDataBean>  retrieveAllTransaction()  {
		List<BlockDataBean> allTransaction=new ArrayList<>();
		allTransaction=fmsRepository.findAll();
		return allTransaction;
	}
	
	
	@RequestMapping(value = "/register", method = RequestMethod.POST, produces = "application/json")
	@ResponseBody
	public RestResponse createNewUser(@RequestBody @Valid final RegisterData user) {
	
		RestResponse response = new RestResponse();
		RegisterData registerData;
		try {
				registerData = new RegisterData();
				registerData.setRegisterType(user.getRegisterType());
				registerData.setFmsInputName(user.getFmsInputName());
				registerData.setFmsmobileNumber(user.getFmsmobileNumber());
				registerData.setFmsEmail(user.getFmsEmail());
				registerData.setFmscompanyName(user.getFmscompanyName());
				registerData.setFmspassword(user.getFmspassword());
				fmsregisterRepository.save(registerData);
				response.setStatus(200);
				response.setMessage("Success");
				// response.setObject(checkUser);
				return response;
			}catch (Exception ex) {
				
				System.out.println(ex);
			System.out.println("DataAnalyticController.createNewUser()");
			response.setStatus(201);
			response.setMessage("Failure");
			return response;

		}



	}

}
