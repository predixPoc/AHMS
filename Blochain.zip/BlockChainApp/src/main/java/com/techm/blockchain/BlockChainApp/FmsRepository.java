package com.techm.blockchain.BlockChainApp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FmsRepository extends JpaRepository<BlockDataBean, Long>{
	


}
