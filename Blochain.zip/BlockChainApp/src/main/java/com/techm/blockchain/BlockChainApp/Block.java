package com.techm.blockchain.BlockChainApp;

import java.util.Arrays;

public class Block {
	
	private int previousHash;
	private String [] transactions;
	private int blockhash;
	
	public Block(int previousHash, String[] transactions) {
		super();
		this.previousHash = previousHash;
		this.transactions = transactions;
		Object [] contens={Arrays.hashCode(transactions),previousHash};
		this.blockhash=Arrays.hashCode(contens);
	}

	public int getPreviousHash() {
		return previousHash;
	}

	

	public String[] getTransactions() {
		return transactions;
	}

	public int getBlockhash() {
		return blockhash;
	}

	
	
	

}
