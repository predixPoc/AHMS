package com.techm.blockchain.BlockChainApp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface FmsRegisterRepository extends JpaRepository<RegisterData, Long>{

}
