package com.techm.blockchain.BlockChainApp;

import java.io.Serializable;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;


@Entity
@Table(name = "fmsRegister")
public class RegisterData implements Serializable {
	
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private Long id;
	
	private String registerType;
		
	private String fmsInputName;
	
	private String fmsmobileNumber;
	
	private String fmsEmail;
	
	private String fmscompanyName;
	
	private String fmspassword;
	
	private String fmsconfirmPassword;

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getRegisterType() {
		return registerType;
	}

	public void setRegisterType(String registerType) {
		this.registerType = registerType;
	}

	public String getFmsInputName() {
		return fmsInputName;
	}

	public void setFmsInputName(String fmsInputName) {
		this.fmsInputName = fmsInputName;
	}

	public String getFmsmobileNumber() {
		return fmsmobileNumber;
	}

	public void setFmsmobileNumber(String fmsmobileNumber) {
		this.fmsmobileNumber = fmsmobileNumber;
	}

	public String getFmsEmail() {
		return fmsEmail;
	}

	public void setFmsEmail(String fmsEmail) {
		this.fmsEmail = fmsEmail;
	}

	public String getFmscompanyName() {
		return fmscompanyName;
	}

	public void setFmscompanyName(String fmscompanyName) {
		this.fmscompanyName = fmscompanyName;
	}

	public String getFmspassword() {
		return fmspassword;
	}

	public void setFmspassword(String fmspassword) {
		this.fmspassword = fmspassword;
	}

	public String getFmsconfirmPassword() {
		return fmsconfirmPassword;
	}

	public void setFmsconfirmPassword(String fmsconfirmPassword) {
		this.fmsconfirmPassword = fmsconfirmPassword;
	}

	
	
	

}
