
app.controller('poSettingsController', function($scope, $filter, $rootScope,$state,Auth,$timeout,constants,
		toaster,$cookies,$cookieStore, WorkFlow, supplier) {
    $rootScope.poSettingsDone = false;
    $scope.loader=true
    $scope.supplierInfo = {};
	// $scope.supplierInfo.payment_terms_check= 425;
	var WfModel = {};
	// $scope.supplierInfo.other_payment_terms_check=="";
	$scope.prevButtonForPosettings=function(){
  	  $state.go('compliance');
    }

    Auth.getRoles().then(function(roles){ 
    	if(!WorkFlow.getRequestId()){

    		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			
			if (Auth.isSupplierRole(roles.roles)){
	       		$state.go('supplierHome');
	    	}else{
	        	$state.go('homePage');
	    	}
	    	return;
	    }

	    if (Auth.isSupplierRole(roles.roles)){
	       	$state.go('supplierHome');
	    }

	}, function(data){
    	$scope.loader=false;
    });


	$scope.doPaymentTermsSearch = function(keyWord){
		$scope.keyWord = keyWord;
		$scope.poPaymentTermsSearchResult = false;
		$scope.loader_poSearch=false;
		$scope.loader_poSearch=true;
		supplier.getCountryById(WfModel.supplier.countryId).then(function(data){			
    		$scope.CountryCode = data.code
			supplier.getPaymentTerms(keyWord, WfModel.subscription.erpId[0], $scope.CountryCode).then(function(data){
				$scope.paymentTermsData = data;
				$rootScope.paymentData=data;
				$scope.loader_poSearch=false;
				if($scope.paymentTermsData.length > 0){
					$scope.poPaymentTermsSearchResult = true;
					$scope.noPaymentFound=false;
					$scope.loader_poSearch=false;
				}else{
					$scope.poPaymentTermsSearchResult = false;
					$scope.noPaymentFound=true;

				}
			}, function(){
				$scope.loader_poSearch=false;
				toaster.pop('error', "Payment Term Search", "server not responding");
			});
		}),function(){
			
		}	
	}
	$scope.getIncoterms = function(){
		supplier.getIncoterms().then(function(data){
			$scope.incoTerms = data;
			return data;
			
		}, function() {
			toaster.pop('error', "incoTerms list", "server not responding");
		});
	}
	$scope.transactionTypeNew=[];
	$scope.getTransactionType = function(){
		supplier.getTransactionType().then(function(data){
			$scope.transactionType = data;
			
			angular.forEach($scope.transactionType, function(item,index){
				$scope.transactionTypeNew.push(item.name)
			});
			return data;
		}, function(){
			toaster.pop('error', "transaction Type list", "server not responding");
		});
	}

	// Default payment terms
	$scope.getPaymentTermsDefault = function(){
		$scope.showOthers = false;
		supplier.getCountryById(WfModel.supplier.countryId).then(function(data){			
    		$scope.CountryCode = data.code
 			supplier.getDefaultPaymentTerms(WfModel.subscription.erpId[0], $scope.CountryCode).then(function(data){
				if(data.changeable){
					$scope.showOthers = true;
				}
				$rootScope.defaultPaymentTermsData = data.paymentsTerms;
				if(WfModel.subscription.paymentTermsId == null && $rootScope.defaultPaymentTermsData!= undefined){
					$scope.supplierInfo.payment_terms_check= $rootScope.defaultPaymentTermsData[0].id;
				}
			}, function(){

			});
    	}),function(){

    	}
	}
	 $scope.selectedTranTypesArray=[]; 
	 $scope.onSelected = function (selectedItem) {
		 angular.forEach($scope.transactionType, function(item,index){ 
				if(item==selectedItem){
					 $scope.selectedTranTypesArray.push(item.id);
				}

			  });
	 }
	 $scope.removed=function(removedItem){
	 
	 angular.forEach($scope.transactionType, function(item,index){ 
			if(item==removedItem){
				 $scope.removeId=item.id;
			}

		  });
	 angular.forEach($scope.selectedTranTypesArray, function(item,index){
		 if(item==$scope.removeId){
			  var index = $scope.selectedTranTypesArray.indexOf(item);
			  $scope.selectedTranTypesArray.splice(index, 1);
		 }
	 
 });
	 }
	
	$scope.getIncoterms();
	$scope.getTransactionType();
	
	
	$scope.save = function(supplierInfo, next) {
		$scope.submitted = true;
		// if(supplierForm.$invalid || !supplierInfo.incoTerms ) {
		// 	toaster.pop('error', "", "Please fill all mandatory fields");	
		// 	return;
		// }
		if(supplierInfo.incoTerms==null && $scope.paymentTermsRuleData.incoTermsId.mandatory == true && $scope.paymentTermsRuleData.incoTermsId.enabled == true){
			  toaster.pop('error', "Inco Terms Id", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.settlementProcessId==null && $scope.paymentTermsRuleData.settlementProcessId.mandatory == true && $scope.paymentTermsRuleData.settlementProcessId.enabled == true){
			  toaster.pop('error', "Settlement Process Id", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.transactionTypeId==null && $scope.paymentTermsRuleData.transactionTypeId.mandatory == true && $scope.paymentTermsRuleData.transactionTypeId.enabled == true){
			  toaster.pop('error', "Transaction Type Id", "Please answer all the mandatory question");	
				return;
		  }
		  if(supplierInfo.payment_terms_check==null && $scope.paymentTermsRuleData.paymentTermsId.mandatory == true && $scope.paymentTermsRuleData.paymentTermsId.enabled == true){
			  toaster.pop('error', "Payment Terms Id", "Please answer all the mandatory question");	
				return;
		  }
		  
		  
		$scope.idForTransactionType=[];
		angular.forEach($scope.transactionType, function(value, key){
			angular.forEach(supplierInfo.transactionType, function(value1, key1){
				if(value1==value.name){
					$scope.idForTransactionType.push(value.id);
				}
		});
		});
		$scope.loader=true;
		WfModel.subscription = (WfModel.subscription==null)?{}:WfModel.subscription;		
		WfModel.subscription.incoTermsId = (supplierInfo.incoTerms.length==0)?null:supplierInfo.incoTerms[0];
		debugger;
		// WfModel.subscription.incoTermsLocation = supplierInfo.incotermLocation;

		// var tempData = [];
		// for (var i = 0; i < $scope.supplierInfo.transactionType.length; i++){
		// 	tempData.push($scope.supplierInfo.transactionType[i]);
		// }
		WfModel.subscription.transactionTypeId = $scope.idForTransactionType;
		WfModel.subscription.settlementProcessId = supplierInfo.settlementProcess;
		if(supplierInfo.payment_terms_check == 0){
			if($scope.myCheck != supplierInfo.paymentTerms && supplierInfo.paymentTerms != undefined){
				WfModel.subscription.paymentTermsId = supplierInfo.paymentTerms;	
			}
			else{
				supplierInfo.paymentTerms=$scope.myCheck
		 		WfModel.subscription.paymentTermsId = supplierInfo.paymentTerms;
			}
		} else {
			// $scope.defaultPaymentTerms.id = supplierInfo.payment_terms_check;
			WfModel.subscription.paymentTermsId = supplierInfo.payment_terms_check;
		}
		// if($scope.myCheck == supplierInfo.paymentTerms){
		// 	WfModel.subscription.paymentTermsId = supplierInfo.paymentTerms;
		// }
		WorkFlow.setVariablesV2(WfModel).then(function(data){
			$rootScope.poSettingsDone = true;
			toaster.pop('success', "Saved successfully");
			$scope.loader=false;
			if(next){
				$state.go('invitation');
			}
		},function(data){
			$scope.loader=false;
			toaster.pop('error','Workflow API', "Server not Responding");
		});	
	}
	
	WorkFlow.getVariablesV2().then(function(workflowData) {
		$scope.loader=true;
		$scope.newSetTransactionValues=[];
		WfModel = workflowData.data;
		$scope.getPaymentTermsDefault();
		if(WfModel.subscription.transactionTypeId!=""||WfModel.subscription.transactionTypeId!=undefined){
			angular.forEach(WfModel.subscription.transactionTypeId, function(value, key){
				angular.forEach($scope.transactionType, function(value1, key1){
					if(value1.id==value){
						$scope.newSetTransactionValues.push(value1.name)
					}
				});
				
			});
		}
		var erpId = "";
		
		angular.forEach(WfModel.subscription.erpId, function(value, key){
			erpId=erpId+"erpId=" + value + "&";
		})
		erpId=erpId.substring(0,erpId.length-1);
		supplier.getSettlementProcess(erpId).then(function(data){
			$scope.settlementProcess = data;
		}, function() {
			toaster.pop('error', "settlement Process list", "server not responding");
		});

		if(WfModel.subscription.erpId.length > 0){
			$scope.loader_label=true;
			supplier.getSubscriberLabel(WfModel.subscription.erpId[0]).then(function(data){
				// $scope.loader=false;
				if(data.erpCountryCode === "FR" || data.erpCountryCode === "DE" || data.erpCountryCode === "ES"){
					$scope.flagLabel1 = true;
					$scope.loader_label=false;
				}else if(data.erpCountryCode === "AU"){
					$scope.flagLabel2 = true;
					$scope.loader_label=false;
				}else if(data.erpCountryCode === "AT" || data.erpCountryCode === "BE" || data.erpCountryCode === "HU" || data.erpCountryCode === "IE"
					|| data.erpCountryCode === "IT" || data.erpCountryCode === "NL" || data.erpCountryCode === "PL" || data.erpCountryCode === "TR"
					|| data.erpCountryCode === "GB"){
					$scope.flagLabel3 = true;
					$scope.loader_label=false;
				}else{
					$scope.loader_label=false;
				}
			}, function(data) {
				$scope.loader_label=false;
				toaster.pop("error", "Subscriber Label", "Server not responding");
			});
		}
		supplier.paymentTermsRule(WfModel.requestId).then(function(data){
			$scope.paymentTermsRuleData = data.data;
		}, function(){

		});

		if(WfModel.subscription.incoTermsId == null || WfModel.subscription.incoTerms == "" || WfModel.subscription.incoTermsId == undefined){
			//get the default
			var commodityId = parseInt(WfModel.subscription.commodityTier1Id);
			supplier.getDefaultIncoterms(WfModel.subscription.erpId[0], commodityId).then(function(data1){
				$scope.supplierInfo.incoTerms = data1;
			}, function(){
				toaster.pop('error', "incoTerms Default Value", "server not responding");
			});
		}else{
			$scope.supplierInfo.incoTerms = parseInt(WfModel.subscription.incoTermsId);
		}
		$scope.supplierInfo.settlementProcess = parseInt(WfModel.subscription.settlementProcessId);
		
		for (var i = 0; i < WfModel.subscription.transactionTypeId.length; i++) {
		    var listName = WfModel.subscription.transactionTypeId;
		    $scope[listName] = [];
		}
		$scope.supplierInfo.transactionType = [];
		$scope.supplierInfo.transactionType=$scope.newSetTransactionValues;
		//$scope.paymentTermsIdChecked=false;
		// if(WfModel.subscription.paymentTermsId == null && $rootScope.defaultPaymentTermsData!= undefined){
		// 	$scope.supplierInfo.payment_terms_check= $rootScope.defaultPaymentTermsData[0].id;
		// }	
		if(WfModel.subscription.paymentTermsId){
			angular.forEach($rootScope.defaultPaymentTermsData, function(value, key){
				if(parseInt(WfModel.subscription.paymentTermsId) == value.id ){
					$scope.supplierInfo.payment_terms_check = parseInt(WfModel.subscription.paymentTermsId);
					$scope.paymentTermsIdChecked=true;
				}		
			});
			if ($scope.paymentTermsIdChecked==false){
				$scope.poPaymentTermsSearchResultRetrive = false;
				$scope.supplierInfo.payment_terms_check = 0;
				$scope.loader_poRetrieve=true;
				$scope.supplierInfo.paymentTerms = WfModel.subscription.paymentTermsId;
				supplier.getPaymentTermsById(WfModel.subscription.paymentTermsId).then(function(data){
					$scope.getPaymentTermsByIdData = data;
					// $scope.supplierInfo.keyWord=data.netDueDays;
					$rootScope.paymentData=data;
					if($scope.getPaymentTermsByIdData != []){
						$scope.poPaymentTermsSearchResultRetrive = true;
						$scope.myCheck = $scope.getPaymentTermsByIdData.id;
						$scope.loader_poRetrieve=false;
					}else{
						$scope.poPaymentTermsSearchResultRetrive = false;
						$scope.loader_poRetrieve=true;
					}
				},function(){});

			}
			//$scope.supplierInfo.payment_terms_check = WfModel.subscription.paymentTermsId;
		}
		//$scope.supplierInfo.transactionType = parseInt(WfModel.subscription.transactionTypeId[0]);
		//$scope.supplierInfo.payment_terms_check = WfModel.subscription.paymentTermsId;			
		
		//$rootScope.poSettingsDone = true;
		$rootScope.complianceDone = true;
		$rootScope.businessInfoDone = true;
		$rootScope.supplierInfoDone = true;
		$scope.loader=false;
	}, function(data){
		$scope.loader=false;
	});

});
