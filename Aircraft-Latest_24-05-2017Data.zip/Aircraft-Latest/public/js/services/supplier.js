'use strict';

app.factory('supplier', ['$q', '$http', '$timeout', '$rootScope', '$cookies', '$cookieStore', 'constants', 'toaster', '$filter',
    function ($q, $http, $timeout, $rootScope, $cookies, $cookieStore, constants, toaster, $filter) {
        var cookie = $cookieStore.get("sc_token");
        var refreshCookie = $cookieStore.get("sc_refresh_token");
        $cookieStore.put("companyAddress", []);
        var searchParams = {};
        var preference = "";
        var supplier = {
            getCookieVal: function () {
                return $cookieStore.get("sc_token");
            },
            setnotificationInterval: function (val) {
                preference = val;
            },
            getnotificationInterval: function () {
                if (preference) {
                    return preference;
                }
            },
            getCountryList: function () {
                var url = constants.GET_COUNTRY_LIST;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    cache: true,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getCountryById: function (code) {
                var url = constants.GET_COUNTRY_CODE + code;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    cache: true,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getCurrencyList: function () {
                var url = constants.GET_CURRENCY_LIST;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getCurrencyListById: function (id) {
            	
                var url = constants.GET_CURRENCY_LIST_BY_ID+id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getBusinessList1: function () {
                var url = constants.GET_BUSINESS_LIST1;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getBusinessSubListNew: function (id) {
                var url = constants.GET_BUSINESS_TABLE + id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getBusinessSubListNewById: function (id) {
                var url = constants.GET_BUSINESS_TABLE_BY_ID + id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getBusinessSubList: function (id) {
                var url = constants.GET_BUSINESS_SUBLIST + id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getBusinessSubscriptionList: function (id) {
                var url = constants.GET_BUSINESS_SUBLIST_NEW + id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getRoutingLabel: function (code) {
                var url = constants.GET_ROUTING_LABEL + code;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getlistFileUploaded: function (id) {
                var url = constants.FILE_LIST + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getCommoditiesFamilyList: function () {
                var url = constants.GET_COMMODITIES_FAMILY_LIST;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getPayTermNameFromVal: function (id) {
                var url = constants.PAYMENT_TERMS_BY_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getCommoditiesSubList: function (id) {
                var url = constants.GET_COMMODITIES_SUBLIST + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getPhoneCodes: function () {
                var url = constants.GET_PHONE_CODES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getIncoterms: function () {
                var url = constants.GET_INCO_TERMS;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getDefaultIncoterms: function (erpId, commodityId) {
                var url = constants.GET_DEFAULT_INCO_TERMS + "?erpId=" + erpId + "&commodityId=" + commodityId;;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSettlementProcess: function (Id) {
                var url = constants.GET_SETTLEMENT_PROCESS + Id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getTransactionType: function () {
                var url = constants.GET_TRANSACTION_TYPES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getPaymentTerms: function (keyword, erpId, countryCode) {
                var url = constants.PAYMENT_TERMS + keyword + "&erpId=" + erpId + "&countryCode=" + countryCode;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getPaymentTermsById: function (id) {
                var url = constants.PAYMENT_TERMS_BY_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getPaymentTermsByIdForSubscribe: function (id) {
                var url = constants.PAYMENT_TERMS_BY_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getDefaultPaymentTerms: function (erpId, countryCode) {
                var url = constants.PAYMENT_TERMS_BY_ID + "?erpId=" + erpId + "&countryCode=" + countryCode;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            paymentTermsRule: function (requestId) {
                var data = {
                    "requestId": requestId
                }
                var url = constants.PAYMENT_TERMS_RULE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getEmailRuleCheck: function (email) {
                var data = {
                    "email": email
                }
                var url = constants.EMAIL_RULE_CHECK;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            bankAccountValidation: function (number, country) {
                if (!country) {
                    toaster.pop('error', "Country", "please choose country");
                }
                var data = {
                    "countryCode": country,
                    "number": number
                }
                var url = constants.ACCOUNT_NUMBER_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            bankLocalAccountValidation: function (number, country) {

                if (!country) {
                    toaster.pop('error', "Country", "please choose country");
                }

                var data = {
                    "countryCode": country,
                    "routing": number
                }
                var url = constants.LOCAL_ACCOUNT_NUMBER_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getStatesList: function (code) {

                var url = constants.GET_STATE_LIST + code;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getGoodTypes: function () {
                var url = constants.GET_GOOD_TYPES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            withHoldingTaxTypes: function (code) {

                var url = constants.WITHHOLDING_TAX_TYPES + code;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            taxAuthority: function (code) {

                var url = constants.TAX_AUTHORITY + code;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setAddress: function (addressObj) {
                var address = $cookieStore.get("companyAddress");
                address.push(addressObj);
                $cookieStore.put("companyAddress", address);
            },
            getAddress: function () {
                return $cookieStore.get("companyAddress");
            },
            deleteAddress: function (index) {
                var address = $cookieStore.get("companyAddress");
                address.splice(index, 1);
                $cookieStore.put("companyAddress", address);
            },
            checkVatTaxApiValidation: function (supplierInfo) {
                /*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/OPENL-WS/REST/1.0/Supplier/Supplier/VATTaxIDValidation/*/
                var data = {
                    "taxId": supplierInfo.taxIdInVat,
                    "authorityId": supplierInfo.taxAuthority
                }
                var url = constants.GET_VAT_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            checkVatTaxApiValidationForSearch: function (supplierData) {
                /*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/OPENL-WS/REST/1.0/Supplier/Supplier/VATTaxIDValidation/*/
                var data = {
                    "taxId": supplierData.vatTaxIdCompanyInfo,
                    "authorityId": supplierData.vatTaxAuthorityCompanyInfo
                }
                var url = constants.GET_VAT_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            diversityRules: function (requestId) {
                var data = {
                    "requestId": requestId
                }
                var url = constants.DIVERSITY_RULE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            checkTaxApiValidation: function (supplierInfo, addNewData,tax) {
                var data = {
                    "country": addNewData.country,
                    "taxId": tax,
                    "classification": supplierInfo.taxClassification
                }
                var url = constants.GET_TAX_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getNewSubscribersForAddNew: function (id) {
                var url = constants.GET_CURRENT_SUBSCRIBERS + id + "/subscriptions";
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            checkTaxApiValidationForSearchPage: function (supplierData, country) {
                
                var data = {
                    "country": country,
                    "taxId": supplierData.taxNumberLegalEntity,
                    "classification": supplierData.taxClassificationLegalEntity
                }
                var url = constants.GET_TAX_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            checkTaxApiValidationForSearchPageForOwner: function (countryCode, supplierData) {
                
                var data = {
                    "country": countryCode,
                    "taxId": supplierData.ownerTaxIdNoLegalEntity,
                    "classification": supplierData.ownerTaxClassifyLegalEntity
                }
                var url = constants.GET_TAX_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            providingValidation: function (incCountry, taxClassify, insideUs, providings) {
                var data = {
                    "incorporationCountry": incCountry,
                    "classification": taxClassify,
                    "subscribingCountry": insideUs,
                    "providing": providings
                }
                /*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/OPENL-WS/REST/1.0/Supplier/Supplier/ProvidingValidation/*/
                var url = constants.PROVIDING_VALIDATION;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getToken: function () {
                //alert("function test");
                var params = {
                    token: refreshCookie,
                }
                var url = constants.GET_TOKEN;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal(),
                        //'token': refreshCookie
                    },
                    url: url,
                    method: 'POST',
                    params: params
                };

                $http(req).then(function (reply) {
                    $cookieStore.put("sc_token", reply.data.token_type + " " + reply.data.access_token);
                    $cookieStore.put("sc_refresh_token", reply.data.refresh_token);
                    $cookieStore.put("sc_expires_in", reply.data.expires_in);
                    d.resolve(reply.params);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getCommodityCheck: function (commodityFamilyId) {
                var url = constants.GET_COMMODITY_CHECK + commodityFamilyId;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSingleBusiness: function (id) {
                var url = constants.SINGLE_BUSINESS + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getDiligence: function (obj, id) {
                var temp = 0;
                angular.forEach(obj, function (value, key) {
                    if (value.type == id) {
                        temp = value.data.key;
                    }

                });
                return temp;
            },
            setDiligence: function (obj, id, value) {
                var flag = 0;
                angular.forEach(obj, function (single, key) {
                    if (single.type == id) {
                        single.data.key = value;
                        flag = 1;
                    }
                });
                if (!flag) {
                    obj.push({
                        "type": id,
                        "data": {"key": value}
                    });
                }
                return obj;
            },
            getDiligenceRules: function (requestIdString) {

                var data = {"requestId": requestIdString};
                var url = constants.DUEDILIGENCE_COMPLIANCE_RULES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);

                }, function (reply) {
                    d.resolve();
                    toaster.pop('error', "Due Diligence Compliance Rules API", "server not responding");
                });
                return d.promise;
            },
            getComplianceSubscribeRules: function (requestIdString) {

                var data = {"requestId": requestIdString};
                var url = constants.COMPLIANCE_RULES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);

                }, function (reply) {
                    d.reject();
                   
                });
                return d.promise;
            },
            getNdaData: function (ndaObj) {

                var data = ndaObj
                var url = constants.NDA_DATA;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);

                }, function (reply) {
                    d.resolve();
                    toaster.pop('error', "NDA Data API", "server not responding");
                });
                return d.promise;
            },
            basicSearch: function (name, address) {
                var url = constants.SEARCH + name + '&address=' + address;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            searchByIndexId: function (obj) {
                var url = constants.SEARCH + obj.text;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            // internalSearchByIndexId: function (obj) {
            //     var url = constants.INTERNAL_SEARCH + obj.text;
            //     var d = $q.defer();
            //     var req = {
            //         headers: {
            //             'Content-Type': 'application/json',
            //             'Authorization': supplier.getCookieVal()
            //         },
            //         url: url,
            //         method: 'POST',
            //     };

            //     $http(req).then(function (reply) {
            //         d.resolve(reply.data);
            //     }, function (reply) {
            //         d.reject();
            //     });
            //     return d.promise;
            // },
            fullSearch: function (obj) {

                var url = constants.SEARCH;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            internalSearch: function (obj) {
                var url = constants.INTERNAL_SEARCH;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj

                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSupplierById: function (id) {
                var url = constants.GET_SUPPLIER_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    cache: true,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getRequestById: function (id) {
                var url = constants.NEW_SET_VARIABLES + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    cache: true,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setSearchParams: function (searchObj) {
                searchParams = searchObj;

                /*	{
                 "addressLine": "string",
                 "commodities": [
                 "string"
                 ],
                 "email": "string",
                 "phone": "string",
                 "status": "ACTIVE",
                 "supplierName": "string",
                 "supplierNumber": "string",
                 "taxId": "string"
                 }*/
            },
            getSearchParams: function () {
                return searchParams;
            },
            getCountryNameFromCode: function (code) {
                var d = $q.defer();
                supplier.getCountryList().then(function (data) {
                    var codeArray = $filter('filter')(data, {'code': code});
                    d.resolve(codeArray[0].name);

                    //$scope.supplierInfo.country = $scope.chooseCountries[0];
                }, function () {
                    toaster.pop('error', "Country list", "server not responding");
                    d.reject();
                });
                return d.promise;

            },
            //find duplicate name
            getDuplicateName: function (name) {
                var data = {
                    "fields": {
                        "name": {
                            "value": name
                        }
                    },
                    "ruleSetId": "ui-dedup"
                }
                var url = constants.DUPLICATE_NAME;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    cache: true,
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            //typeahead api
            getTypeAhead: function (text) {
                var data = {
                    "text": text
                }
                var url = constants.LOOKHEAD_SEARCH;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getInternalTypeAhead: function (text) {
                var data = {
                    "text": text
                }
                var url = constants.INTERNAL_LOOKHEAD_SEARCH;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getBankUIRule: function (obj) {
                var data = obj;
                var url = constants.BANK_DISPLAY_RULE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getAgentTypes: function () {
                var url = constants.GET_AGENT_TYPES;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getCompanyPageUiVisibility: function (obj) {
                var url = constants.GET_COMPANY_UI_VISIBILITY;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj
                };

                $http(req).then(function (reply) {

                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSubscriberLabel: function (id) {
                var url = constants.GET_SUBSCRIBER_LABEL + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSubscriberLabelSubscribe: function (id) {
                var url = constants.GET_SUBSCRIBER_LABEL + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            termsApprove: function () {
                var url = constants.TERMS;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getAddressRule: function (id) {
                var data = {"requestId": id};
                var url = constants.ADDRESS_RULE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data


                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            // ABA Routing Validation
            abaNumberRouting: function (abanumber, aba_number_country) {
                var url = constants.ABANUMBER_ROUTING + "id=" + abanumber + "&countryCode=" + aba_number_country;
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    //reply.data  = true;
                    d.resolve(reply.data);
                }, function (reply) {
                    //reply.data  = true;
                    //d.resolve(reply);
                    d.reject(reply.data);
                });
                return d.promise;
            },
            //get the swift bank name
            getBankName: function (abanumber, aba_number_country) {
                var url = constants.SWIFT_GET_BANK_NAME + "id=" + abanumber + "&countryCode=" + aba_number_country;
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    //reply.data  = true;
                    d.resolve(reply.data);
                }, function (reply) {
                    //reply.data  = true;
                    //d.resolve(reply);
                    d.reject(reply.data);
                });
                return d.promise;
            },
            //BBAN VALIDATION
            IbanAccountValidation: function (bbanNumber) {
                var url = constants.BBAN_VALIDATION + "id=" + bbanNumber;
                //id=191001111111&countryCode=AT
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    //reply.data  = true;
                    d.resolve(reply.data);
                }, function (reply) {
                    //reply.data  = true;
                    //d.resolve(reply);
                    d.reject();
                });
                return d.promise;
            },
            swiftValidation: function (swiftNumber) {
                var url = constants.SWIFT_VALIDATION + "id=" + swiftNumber;

                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    //reply.data  = true;
                    d.resolve(reply.data);
                }, function (reply) {
                    //reply.data  = true;
                    //d.resolve(reply);
                    d.reject();
                });
                return d.promise;
            },
            riskLevel: function (id) {
                var url = constants.RISK_LEVEL;
                var data = {"requestId": id}
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: data
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            setNotification: function (obj) {
                var url = constants.NOTFICATION_API.replace("#userId#", $cookieStore.get("uId"));
                //var data = {"requestId" :id}	
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'PUT',
                    data: obj

                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });

                return d.promise;
            },
            getNotification: function () {
                var url = constants.NOTFICATION_API.replace("#userId#", $cookieStore.get("uId"));
                var d = $q.defer();


                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getNotificationDiliveryType: function () {
                var url = constants.GET_NOTFICATION_DILIVERY_TYPE;
                var d = $q.defer();


                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getNotificationsIntervalTypes: function () {
                var url = constants.GET_NOTFICATION_INTERVALS_TYPES;
                var d = $q.defer();


                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSupplierDetails: function (id) {
                var url = constants.GET_SUPPLIER_DETAILS + id;
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSupplierDetailsForSubscribe: function (id) {
                var url = constants.GET_SUPPLIER_DETAILS + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            
            getSupplierDetailsForSearch: function (obj) {
                var url = constants.GET_SUPPLIER_DETAILS_FOR_SEARCH;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data:obj
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getRequestDetails: function (id) {
                var url = constants.GET_REQUEST_DETAILS + id;
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            //AC NUMBER VALIDATION
            AccountNumberFormat: function (acNumberformat, acno_format_country) {
                var url = constants.AC_NUMBER_VALIDATION;
                var obj = {"countryCode": acno_format_country, "number": acNumberformat}
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            //LocalRoutingFormatValidation 
            LocalRoutingFormat: function (localformat, local_routing_country) {
                var url = constants.LOCALROUTING_FORMAT_VALIDATION;
                var obj = {"countryCode": local_routing_country, "routing": localformat}
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcommodityValueFromId: function (id) {
                var url = constants.GET_COMMODITY_FROM_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcommodityValueFromIdForSubscribe: function (id) {
                var url = constants.GET_COMMODITY_FROM_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getbusinessLevelsNameFromID: function (id) {
                var url = constants.GET_BUSINESSNAME_FROM_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'

                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getbusinessLevelsNameFromIDForSubscribe: function (id) {
                var url = constants.GET_BUSINESSNAME_FROM_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true

                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            processTypeSubscribe: function (obj) {
                var url = constants.PROCESS_TYE_SUBSCRIBE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'PUT',
                    data: obj,
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcurrentSubscribers: function (entType, entId, supplierId) {
                var url = constants.GET_CURRENT_SUBSCRIBERS + supplierId + "/entity/" + entType + "/" + entId + "/subscribers";

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcurrentSubscribersInSearcPage: function (entType, entId, supplierId) {
                var url = constants.GET_CURRENT_SUBSCRIBERS + supplierId + "/entity/" + entType + "/" + entId + "/subscriptions";

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSubscriptionDetailsForIdFromSearch: function (id) {
                var url = constants.GET_CURRENT_SUBSCRIBERS_FROM_ID + id + '/';
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getCommoditiesFromSupplierInSearch: function (id) {
                var url = constants.GET_CURRENT_SUBSCRIBERS_COMMODITY + id + "/commodities";

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            saveSubscriberDetails: function () {

            },
            getCommodityListOnPayLoad: function (id) {
                var url = constants.GET_COMMODITYLIST_PAYLOAD_SUBSCRIBE + id + "/commodities";

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcurrentSubscribersForCommodity: function (text, item, supplierId) {
                var url = constants.GET_CURRENT_SUBSCRIBERS_COMMODITY + supplierId + "/commodities/subscribers?commodityTier1Id=" + item.tier1Id + "&commodityTier2Id=" + item.tier2Id + "&commodityTier3Id=" + item.tier3Id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getcurrentSubscribersForCommodityFromSearch: function (text, item, supplierId) {
                var url = constants.GET_CURRENT_SUBSCRIBERS_COMMODITY + supplierId + "/commodities/subscribers?commodityTier1Id=" + item.tier1Id + "&commodityTier2Id=" + item.tier2Id + "&commodityTier3Id=" + item.tier3Id;

                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            editCreateWorkflow: function (text) {
                var mainData = "" + text + "";
                var data = {"processType": mainData}
                var url = constants.PROCESS_TYE_SUBSCRIBE;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    data: data,
                    method: 'PUT'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getWithHoldingTaxTypeById: function (id) {
                var url = constants.GET_WITHHOLDING_TYPES_BY_ID + id;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET',
                    cache: true
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getSupplierPayterms: function (id) {
                var url = constants.GET_SUPPLIER_PAYTERMS.replace("#supplierId#", id);
                ;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getAllPaymentTerms: function (erpId, countryCode) {
                // if (paymentId==undefined || paymentId == null) {
                //     var url = constants.PAYMENT_TERMS_BY_ID + "?erpId=" + erpId + "&countryCode=" + countryCode;
                // }else{
                //     var url = constants.PAYMENT_TERMS_BY_ID + paymentId;
                // }
                var url = constants.PAYMENT_TERMS_BY_ID + "?erpId=" + erpId + "&countryCode=" + countryCode;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;

            },
            getAllPaymentTermsById: function (paymentId) {
                var url = constants.PAYMENT_TERMS_BY_ID + paymentId;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getMyData: function () {
                var url = constants.myData_list;
                var obj = {"code": ownerContactSsoId, "value": user_id};
                var d = $q.defer();

                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'POST',
                    data: obj
                };

                $http(req).then(function (reply) {
                    d.resolve(reply.data);
                }, function (reply) {
                    d.reject();
                });
                return d.promise;
            },
            getBranchInfo: function (abanumber, aba_number_country) {
                //var url =constants.SHOW_BRANCH_INFO;
                var url = constants.SHOW_BRANCH_INFO + "id=" + abanumber + "&countryCode=" + aba_number_country;
                var d = $q.defer();
                var req = {
                    headers: {
                        'Content-Type': 'application/json',
                        'Authorization': supplier.getCookieVal()
                    },
                    url: url,
                    method: 'GET'
                };
                $http(req).then(function (finaldata) {
                    d.resolve(finaldata.data);
                }, function (finaldata) {
//reply.data  = true;
//d.resolve(reply);
                    d.reject(finaldata.data);
                });
                return d.promise;
            }

        }
        return supplier;
    }
]);