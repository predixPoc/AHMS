$(document).ready(function (){
$('#fmsRegister').click(function() {
	
	//var registerType=$("#registerType").val();
	//var fmsInputName=$("#fmsInputName").val();
	//var fmsmobileNumber=$("#fmsmobileNumber").val();
	//var fmsEmail=$("#fmsEmail").val();
	//var fmscompanyName=$("#fmscompanyName").val();
	//var fmspassword=$("#fmspassword").val();
	//var fmsConfirmPassword=$("#fmsconfirmPassword").val();
	
	 var registerurl="http://localhost:8082/register";
	              $.ajax({
		             url:registerurl,
                     type: "POST", //send it through post method
		             contentType: "application/json",
                     data :JSON.stringify({
				         registerType :$("#registerType").val(),
						 fmsInputName :$("#fmsInputName").val(),
                         fmsmobileNumber:$("#fmsmobileNumber").val(),
                         fmsEmail: $("#fmsEmail").val(),
                         fmscompanyName: $("#fmscompanyName").val(),
						 fmspassword: $("#fmspassword").val(),
					 }),
                     success: function(responseData) {
				        console.log(responseData.status);
                	    if((responseData.status == 200)&&(responseData.message == "Success")){
                	 	     console.log("Success");
                            
							 alert("User registered successfully.");
                	    }else{
                	 	     console.log("Error");
                	 	     $("#errorDiv").show();
                             $("#errorDiv").css("background-color", "red");
                             $("#errorDiv").html("Error while doing Registration");
                	    }
		
     		         },
                     error: function ( xhr, status, error) {
				       console.log("Error while doing registration.");

	                 }
		         });
	
	
	
});
});