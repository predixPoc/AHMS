 $(document).ready(function () {
	 
	 $("#loginclick").click(function(){
		 
			//location.href = "index_trackTrace.html";
			//window.open("index_trackTrace.html","_self");
			//location.replace("index_trackTrace.html");
			window.location = "homePage.html";
		 
	 });
 });