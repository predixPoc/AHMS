
app.controller('navigationController', function ($scope, $filter, $http, $rootScope, $state, $timeout, toaster, constants,
        $cookies, $cookieStore, $location, WorkFlow, supplier) {
   // console.log($state.current.name);
    $scope.nav = {};
    $scope.myDataAccess = false;
   
    
    if ($state.current.name == 'homePage') {
        $scope.nav.activeItem = 'home';
    } else if ($state.current.name == 'entityVerification') {
        $scope.nav.activeItem = 'Tasks';
    } else if ($state.current.name == 'supplierSearch') {
        $scope.nav.activeItem = 'Search';
    } else if ($state.current.name == 'myData') {
        $scope.nav.activeItem = 'myData';
    } else if ($state.current.name == 'dashboard') {
        $scope.nav.activeItem = 'Dashboard';
    }
	else if ($state.current.name == 'invoice') {
        $scope.nav.activeItem = 'invoice';
    }
	else if ($state.current.name == 'payment') {
        $scope.nav.activeItem = 'payment';
    }	else {
        $scope.nav.activeItem = '';
    }


    

//Go to my data page
    $scope.gotohome = function () {	
        $scope.nav.activeItem = 'homePage';
        $state.go('homePage');
    }

   
    $scope.invoice = function () {
        console.log($scope.nav.activeItem);
        $scope.nav.activeItem = 'invoice';
        $state.go('invoice');
    }

    $scope.payment = function () {
        $scope.nav.activeItem = 'payment';
        $state.go('payment');
    }
    $scope.myDashboard = function () {
        $scope.nav.activeItem = 'Dashboard';
        $state.go('dashboard');
    }


});