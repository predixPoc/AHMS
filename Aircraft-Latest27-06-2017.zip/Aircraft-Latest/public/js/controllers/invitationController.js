
app.controller('invitationController', function($scope, $filter, $http, $rootScope,$state,Auth,$timeout,constants,
		toaster,$cookies,$cookieStore, WorkFlow, supplier) {	
	$scope.loader=true;
	$scope.supplierInfo = {};
	
	Auth.getRoles().then(function(roles){ 
    	if(!WorkFlow.getRequestId()){

    		toaster.pop('error', "No Open Task found !", "Request Id is retrieving as null");
			
			if (Auth.isSupplierRole(roles.roles)){
	       		$state.go('supplierHome');
	    	}else{
	        	$state.go('homePage');
	    	}
	    	return;
	    }

	    if (Auth.isSupplierRole(roles.roles)){
	       	$state.go('supplierHome');
	    }

	}, function(data){
    	$scope.loader=false;
    });
	
	var cookie = $cookieStore.get("sc_token");
    	$scope.backButton="Back";
	   	$scope.saveButton="Save";
	   	$scope.nextButton="Invite";
	   	$scope.backButtonShow=true;
	   	$scope.saveButtonShow=true;
	   	$scope.nextButtonShow=true;
	   	$scope.isSelfServeSupplierInvited=true;
  	 	$scope.firstName = localStorage.getItem("firstName");
	   	$scope.lastName = localStorage.getItem("lastName");
	   	$scope.email =  $cookieStore.get("email");
	   	$scope.ssoEmail = localStorage.getItem("ssoemail");
	   	$scope.supplierName =  $cookieStore.get("supplierName");
	   
	   // if($scope.supplierFirstName == "" || $scope.supplierFirstName == null){
	   // 		$scope.supplierFirstName = "Sir/Madam";
	   // }
	   
	   	$scope.date = $filter('date')(new Date(), 'MMMM d, yyyy');
	
	   	$rootScope.invitationDone = true;
	   	$scope.prevForInvitation=function(){

		   $state.go('poSettings');
	   	}
	   	$scope.invitationYesNo = 1;
	   
	   	$scope.commonWFTask = function (text) {
		  $scope.loader=true; 
		   var dataObject = [
		   		{
				    "name":"geContactSso",
				    "value":localStorage.getItem("userId")
				},
				{"name":"uaaId","value":"gesso"}
			]
			WorkFlow.completeWorkflowV2().then(function(data) {				
				$scope.completed = data.completed;
				if($scope.completed === false){
					toaster.pop('error', data.fault[0]);
					$state.go('invitation');
					$scope.loader=false;
				}else{
					if(text=="mail"){
					$scope.loader=false;
					toaster.pop('success', "WorkFlow Completed successfully");
					$state.go('homePage');
					$cookieStore.remove("instanceId");
				    $cookieStore.remove("taskId");
				    $cookieStore.remove("requestId");
				    
					}
					else if(text=="withoutMail"){
						$scope.loader=false;
						toaster.pop('success', "WorkFlow Completed successfully");
						$state.go('supplierProfileCompany');
						$cookieStore.remove("instanceId");
					    $cookieStore.remove("taskId");
					    $cookieStore.remove("requestId");
					}
				}
			}, function(data) {
				toaster.pop('error', "Complete WorkFlow API failling !");
				$scope.loader=false;

			});	
	   }

		var req = {
				method : 'POST',
				data:{
					'templateType': 'onBoardingInviteEmailTemplate'
				},
				url :constants.GET_EMAIL_CONTENT,
				headers : {

					'Content-Type' : 'application/json',
					'Authorization' : WorkFlow.getCookieVal()
						}
			}

			$http(req).then(function(response){
			$scope.mailContent=response.data.content;
			$scope.mailTitle=response.data.title;
			$scope.mailSubject = response.data.subject;
			$scope.loader=false;
//            console.log("content",response);
			}, function(){
				$scope.loader=false;
				toaster.pop('error', "Email Content", "Some error happend .Please try again after sometime.");  
			
			});
		
		$scope.getAllEmailContents=function(){
			$scope.loader=true;
			var req = {
					method : 'GET',
					url :constants.GET_EMAIL_ALL_CONTENT,
					headers : {

						'Content-Type' : 'application/json',
						'Authorization' : WorkFlow.getCookieVal()
							}
				}
			$http(req).then(function(response){
				$scope.contentsLoop=response.data;
				$scope.loader=false;
//				console.log("$scope.contentsLoop",$scope.contentsLoop)
			}, function(){
				$scope.loader=false;
				toaster.pop('error', "Get All Email Contents", "Some error happend .Please try again after sometime.");  
			
			});
		}

	   	$scope.next = function(supplierInfo, text) {
		   if(text=="save") {
			   $scope.saveButtonShow=false;
			   $scope.nextButton="Submit"; 
		   	}
		   	else if(text=="next"  && $scope.invitationYesNo == 1){
			   	$scope.loader=true;
			   	WfModel.dueDiligence  = (WfModel.dueDiligence==null)?{}:WfModel.dueDiligence;
		   	    WfModel.dueDiligence.isSelfServeSupplierInvited = $scope.isSelfServeSupplierInvited;
		   	    WorkFlow.setVariablesV2(WfModel).then(function(data){
		   	    	$scope.loader=false;
		   	    	$scope.commonWFTask("mail");
		   	    	
				},function(data){
					toaster.pop('error', "Request Api error", "Some error happend .Please try again after sometime."); 
					$scope.loader=false;
				});
			   	
				if($scope.email!=""){
					// $scope.supplierFirstName = WfModel.onboardingContact.firstName;
	   	// 			$scope.supplierLastName =  WfModel.onboardingContact.lastName;
					// if($scope.supplierFirstName == "" || $scope.supplierFirstName == null){
					//    	$scope.supplierFirstName = "Sir/Madam";
					// }
					var dataJsonAddUser={
								"name":"Supplier",
								"text":"<div style='font-family: Arial,Helvetica Neue,Helvetica,sans-serif; font-size:14px;'><b style='float:left'>Dear "+$scope.supplierFirstName+"</b>"+
								$scope.mailContent +"<b>Sincerely,<br>"+ $scope.firstName+" "+$scope.lastName  +"</b><br><br><br>If you prefer not to receive the notification email messages from GE Supplier Connect, please <a href='' target='_blank'>click here</a> to unsubscribe.</div>",							
								"subject": $scope.mailSubject,
								"cc":["deepak.ramrakhiyani1@ge.com", $scope.ssoEmail], 
								"to": $scope.email,
								"from":$scope.ssoEmail
					}
				 	
//					console.log("dataJsonAddUser",dataJsonAddUser);
		
					var req = {
						method : 'POST',
						/*https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/PC_NOTIFICATION/pcNotification/simplemail*/
						url :constants.SEND_MAIL,
						headers : {
		
							'Content-Type' : 'application/json',
							'Authorization' : WorkFlow.getCookieVal()
		
						},
						data : dataJsonAddUser
					}
				   
					$http(req).then(function(response){
						$scope.loader=false;
						toaster.pop('success', "Sending Mail", "Your mail has been successfully sent !");
					}, function(){
						$scope.loader=false;
						toaster.pop('error', "Server Error", "Some error happend .Please try again after sometime.");  
					
					});	
				}
				
		   /*else if stop*/
		   }
		    else if(text=="next"  && $scope.invitationYesNo == 0){
		   	    //WfModel.supplier = (WfModel.supplier==null)?{}:WfModel.supplier;
		   	    $scope.loader=true;
		   	    supplierInfo.userId=localStorage.getItem('userId');
		   	    WfModel.onboardingContact = (WfModel.onboardingContact==null)?{}:WfModel.onboardingContact;
		   	    WfModel.onboardingContact.userId = supplierInfo.userId;
		   	    WfModel.dueDiligence  = (WfModel.dueDiligence==null)?{}:WfModel.dueDiligence;
		   	    WfModel.dueDiligence.isSelfServeSupplierInvited = $scope.isSelfServeSupplierInvited;
		   	    WorkFlow.setVariablesV2(WfModel).then(function(data){
		   	    	$scope.loader=false;
		   	       $scope.commonWFTask("withoutMail");
				},function(data){
				     toaster.pop('error', "Request Api error", "Some error happend .Please try again after sometime."); 
					$scope.loader=false;
				});
			 
			   
			    
		    }
			
		}
	   $scope.invitationNo=function(){
		   $scope.invitationYesNo = 0;
		   $scope.isSelfServeSupplierInvited=false;
		   $scope.nextButton="Next";
		   $scope.saveButtonShow=false;
	   }
	   $scope.invitationYes=function(){
		   $scope.saveButtonShow=true;
		   $scope.isSelfServeSupplierInvited=true;
		   $scope.nextButton="Invite";
		   $scope.invitationYesNo = 1;
		   
	   }
	    var WfModel = {};
		WorkFlow.getVariablesV2().then(function(workflowData) {		
		 	WfModel = workflowData.data;
		 	$scope.supplierFirstName = WfModel.onboardingContact.firstName;
			$scope.supplierLastName =  WfModel.onboardingContact.lastName;
			if($scope.supplierFirstName == "" || $scope.supplierFirstName == null){
			   	$scope.supplierFirstName = "Sir/Madam";
			}
		}, function(data) {
			$scope.loader=false;
		});			
		$scope.getNewEmailTemplate=function(id){
			$scope.newVal=id;
		}
     	$scope.submitTemplate=function(){
    	  $scope.loader=true;
//    	  console.log($scope.contentsLoop);
    	  angular.forEach($scope.contentsLoop, function(value, key) {
    		if(value.id==$scope.newVal){

    			$scope.selectedValue=value.id;
        		var req = {
    					method : 'GET',
    					url :constants.GET_EMAIL_ALL_CONTENT_BYID+$scope.selectedValue,
    					headers : {

    						'Content-Type' : 'application/json',
    						'Authorization' : WorkFlow.getCookieVal()
    							}
    				}
      
    			$http(req).then(function(response){
    				$scope.loader=false;
//    				console.log("res",response)
    				$('#myModal').modal('toggle');
    				toaster.pop('success', "Selected Email Contents", "Successfully seleted new Email Content.");
    				$scope.mailContent=response.data.content;
    				$scope.mailTitle=response.data.title;
    				$scope.newMailContents=response.data.content;
    				$scope.mailSubject = response.data.subject;
    			}, function(){
    				$scope.loader=false;
    				toaster.pop('error', "Get All Email Contents", "Some error happend .Please try again after sometime.");  
    			
    			});
    		}

    		
    		});
      }

	
});
