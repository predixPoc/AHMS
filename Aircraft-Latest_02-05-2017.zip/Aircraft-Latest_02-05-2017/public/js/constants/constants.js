'use strict';

app.constant('constants', (function() {
	var supplierApiUrl;
	var supplierLoginUrl;

    var fullUrl = window.location.href;
    var extractUrl = fullUrl.split('//');
    var extractUrl1=extractUrl[1];
    var extractUrl2 = extractUrl1.split('/');
    var finalUrl = extractUrl2[0]+"/"; 




	supplierApiUrl = 'https://' + finalUrl; 
    //supplierApiUrl = 'https://pc-api-gateway-ui.run.asv-pr.ice.predix.io/';
	supplierLoginUrl = 'https://supplierconnect-auth.run.asv-pr.ice.predix.io/supplierconnect/login'
   //workflowUrl:'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/PC_WORKFLOW';

    return {
	  //supplier.js
    SUPPLIER_API_URL:'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/',
    GET_COUNTRY_LIST: supplierApiUrl+'pc-reference-data/countries/?sortBy=name&sortOrder=ASC',
    GET_COUNTRY_CODE:supplierApiUrl+'pc-reference-data/countries/',
    GET_STATE_LIST: supplierApiUrl+'pc-reference-data/states/?sortBy=subdivisionName&sortOrder=ASC&countryCode=',
    GET_BUSINESS_LIST1:supplierApiUrl +'pc-reference-data/subscriber_levels/root/?sortBy=name&sortOrder=ASC',
    //GET_BUSINESS_SUBLIST:supplierApiUrl +'pc-reference-data/business_levels/?parentFk=',
    GET_BUSINESS_SUBLIST:supplierApiUrl +'pc-reference-data/subscriber_levels/?sortBy=name&sortOrder=ASC&parentFk=',
    GET_BUSINESS_TABLE:supplierApiUrl +'pc-reference-data/subscribers/?parentFk=',
    GET_BUSINESS_TABLE_BY_ID: supplierApiUrl +'pc-reference-data/subscribers/',
    GET_SUBSCRIBER_LABEL:supplierApiUrl +'pc-reference-data/subscribers/',
    GET_ROUTING_LABEL:supplierApiUrl +'pc-reference-data/bank_routings_accounts/?countryCode=',
    SINGLE_BUSINESS:supplierApiUrl +'pc-reference-data/business_levels/',
    GET_COMMODITIES_FAMILY_LIST:supplierApiUrl +'pc-reference-data/commodities/?level=1&sortBy=name&sortOrder=ASC',
    GET_COMMODITIES_SUBLIST:supplierApiUrl +'pc-reference-data/commodities/?sortBy=name&sortOrder=ASC&parentFk=',
    //GET_COMMODITIES_LIST:supplierApiUrl +'pc-reference-data/commodities/?parentFk=',
    //GET_PHONE_CODES:supplierApiUrl +'pc-reference-data/phone_codes/?sortBy=country&sortOrder=ASC',
    GET_PHONE_CODES:supplierApiUrl +'pc-reference-data/phone_codes_iso/?sortBy=name&sortOrder=ASC',
    GET_INCO_TERMS:supplierApiUrl +'pc-reference-data/inco_terms/',
    GET_DEFAULT_INCO_TERMS: supplierApiUrl +'pc-reference-data/inco_terms/default/',
    GET_SETTLEMENT_PROCESS:supplierApiUrl +'pc-reference-data/settlement_processes/?',
    GET_TRANSACTION_TYPES: supplierApiUrl+'pc-reference-data/transaction_types/?sortBy=name&sortOrder=ASC',
    GET_EMAIL_CONTENT:supplierApiUrl +'pc-onboarding-util/v1/email/content/active',
    GET_EMAIL_ALL_CONTENT:supplierApiUrl +'pc-onboarding-util/v1/email/contents',
    GET_EMAIL_ALL_CONTENT_BYID:supplierApiUrl +'pc-onboarding-util/v1/email/content/',
    GET_AGENT_TYPES:supplierApiUrl +'pc-reference-data/supplier_types/?sortBy=name&sortOrder=ASC',
    GET_COMPANY_UI_VISIBILITY:supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/CompanyInfoRule/',
    PAYMENT_TERMS_RULE:supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/PaymentTerms/',
    GET_CHECKMODE:supplierApiUrl +'openl-ws/REST/1.0//Supplier/Supplier/BridgerIntegration',
    PAYMENT_TERMS:supplierApiUrl +'pc-reference-data/payment_terms/?keyWords=',
    PAYMENT_TERMS_BY_ID:supplierApiUrl +'pc-reference-data/payment_terms/',
    EMAIL_RULE_CHECK:supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/isEmailValid/',
    ACCOUNT_NUMBER_VALIDATION: supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/AccountNumberFormatValidation/',
    LOCAL_ACCOUNT_NUMBER_VALIDATION: supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/LocalRoutingFormatValidation/',
    GET_GOOD_TYPES:supplierApiUrl +'pc-reference-data/goods_types/',
    GET_WITHHOLDING_TYPES_BY_ID:supplierApiUrl +'pc-reference-data/withholding_tax_types/',
    WITHHOLDING_TAX_TYPES:supplierApiUrl +'pc-reference-data/withholding_tax_types/?sortBy=name&sortOrder=ASC&countryCode=',
    TAX_AUTHORITY:supplierApiUrl +'pc-reference-data/vat_classification/?sortBy=taxAuthority&sortOrder=ASC&countryCode=',
    GET_CURRENCY_LIST:supplierApiUrl +'pc-reference-data/currencies/?sortBy=currencyCode&sortOrder=ASC',
    GET_VAT_VALIDATION:supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/VATTaxIDValidation/',
    GET_TAX_VALIDATION:supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/TaxWithholding/',
    PROVIDING_VALIDATION:supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/ProvidingValidation/',
    GET_CURRENCY_LIST_BY_ID:supplierApiUrl +'pc-reference-data/currencies/',
    GET_COMMODITY_CHECK:supplierApiUrl+'pc-reference-data/commodities/',
    DIVERSITY_RULE: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/Certification/',
    GET_SUPPLIER_DETAILS:supplierApiUrl+'pc-partymaster/suppliers/',
    GET_REQUEST_DETAILS:supplierApiUrl+'pc-request/requests/',
    GET_COMMODITY_FROM_ID:supplierApiUrl+'pc-reference-data/commodities/',
    GET_BUSINESSNAME_FROM_ID:supplierApiUrl+'pc-reference-data/subscriber_levels/',
    PROCESS_TYE_SUBSCRIBE:supplierApiUrl+'pc-workflow/process/supplier',
    GET_CURRENT_SUBSCRIBERS:supplierApiUrl+'pc-pubsub/suppliers/',
    GET_COMMODITYLIST_PAYLOAD_SUBSCRIBE:supplierApiUrl+'pc-pubsub/suppliers/',
    GET_CURRENT_SUBSCRIBERS_COMMODITY:supplierApiUrl+'pc-pubsub/suppliers/',
    GET_CURRENT_SUBSCRIBERS_FROM_ID:supplierApiUrl+'pc-pubsub/subscription/',
    GET_SUPPLIER_PAYTERMS:supplierApiUrl+'pc-pubsub/suppliers/#supplierId#/payterms/',
    SHOW_BRANCH_INFO:supplierApiUrl+'pc_swiftref/v1/swiftref/national-id/detail?',
    GET_SUPPLIER_DETAILS_FOR_SEARCH:supplierApiUrl+'pc-onboarding-util/v1/onboardingSearchParser',
    //Auth.js
    LOGIN :supplierLoginUrl ,
    GET_ROLES : supplierApiUrl+'userroles',
    // Due Diligence compliance
     DUEDILIGENCE_COMPLIANCE_RULES :supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/DueDiligence/',
     NDA_DATA :supplierApiUrl +'pc-onboarding-util/v1/nda/content/active',
     
    //Compliance
    COMPLIANCE_URL :supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/DueDiligenceQuestion/',
    COMPLIANCE_RULES :supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/Compliance/',
    COMPLIANCE_PERFORM:supplierApiUrl+'pc-reference-data/asp_functions/?sortBy=name&sortOrder=ASC',

    //Workflow.js
    CREATE_INSTANCE :supplierApiUrl+'pc-workflow/runtime/process-instances',
    GET_TASKID : supplierApiUrl+'pc-workflow/runtime/tasks?processInstanceId=',
    ASSIGN_TASK : supplierApiUrl+'pc-workflow/runtime/tasks/',
    SET_VARIABLES: supplierApiUrl+'pc-workflow/runtime/process-instances/',
    COMPLETE_TASK: supplierApiUrl+'pc-workflow/runtime/tasks/',
    CANCEL_TASK: supplierApiUrl+'pc-workflow/runtime/tasks/',
    GET_HISTORY: supplierApiUrl+'pc-workflow/history/historic-process-instances?processInstanceId=',
    GET_AVAILABLE_TASK: supplierApiUrl+'pc-workflow/task/available',

    //WORKFLOW NEW
    START_INSTANCE: supplierApiUrl+'pc-workflow/process/supplier/onboarding/add',
    NEW_SET_VARIABLES: supplierApiUrl+'pc-request/requests/',
    CANCEL_WORKFLOW: supplierApiUrl+'pc-workflow/task/',
    COMPLETE_WORKFLOW: supplierApiUrl+'pc-workflow/task/',
    NEW_AVAILABLE_TASK: supplierApiUrl+'pc-workflow/supplier/onboarding/tasks/assigned/?taskType=INVITE_NEW_SUPPLIER_SELF_SERVE',
    GET_REQUEST_ID: supplierApiUrl+'pc-workflow/process/',
    SUPPLIER_REVIEW_REQUEST: supplierApiUrl+'pc-onboarding-util/v1/request/review/',

    //SignInController
    USERS_AUTHORIZE :supplierApiUrl+'pc-access-control/users/authorize',

    //InvitationController
    SEND_MAIL :supplierApiUrl+'pc-notification/v1/pcNotification/simplemail',

    //HeaderController
    GET_PROFILE : supplierApiUrl+'userinfo',

    //OnboardingSupplierProfileCompanyController
    FILE_UPLOAD :supplierApiUrl+'pc_document_management/v2/supplier/document/push?docType=',
    FILE_DOWNLOAD: supplierApiUrl+'pc_document_management/v2/supplier/document/download/',
    FILE_LIST: supplierApiUrl+'pc_document_management/v2/supplier/document/filename/',
	FILE_UPLOAD_MULTIPLE: supplierApiUrl+'pc_document_management/v2/supplier/document/pushFiles',
	FILE_MULTIPLE_LIST: supplierApiUrl+'pc_document_management/v2/supplier/document/pullFiles',
	//idlePopupController
	GET_TOKEN :supplierApiUrl+'refresh-token',

	//terms
	TERMS: supplierApiUrl+'pc-access-control/users/terms_and_conditions/approve',
	
	//Bank
	BANK_DISPLAY_RULE: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/BankInfoRule',
	
	// Address rule
	ADDRESS_RULE: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/manufacturingAddress/',
	
	//Search 
	//SEARCH: supplierApiUrl+'pc-search/search/',

    //search parser
    SEARCH: supplierApiUrl+'pc-onboarding-util/v1/searchSupplierParser/',
    //INTERNAL_SEARCH: supplierApiUrl +'pc-search/search/internals',
    INTERNAL_SEARCH: supplierApiUrl +'pc-onboarding-util/v1/searchSupplierParser/',
    //FULL_SEARCH: supplierApiUrl+'pc-search/search',
    LOOKHEAD_SEARCH: supplierApiUrl+'pc-search/suggest',
    INTERNAL_LOOKHEAD_SEARCH: supplierApiUrl+'pc-search/suggest/internals',
	//GET_REQUEST_ID: 'https://pcrequest-dev.run.asv-pr.ice.predix.io/requests/',
	//GET_SUPPLIER_ID: 'https://pcpartymaster-dev.run.asv-pr.ice.predix.io/suppliers/',
	GET_SUPPLIER_ID: supplierApiUrl+'pc-partymaster/suppliers/',
	SEARCH_WF_SAVE : supplierApiUrl+'pc-request/requests/',

	//Duplicate name
	DUPLICATE_NAME: supplierApiUrl+'pc-match/match/single',
	//https://pcmatch-dev.run.asv-pr.ice.predix.io/match/single


	//Routing Number 
	ABANUMBER_ROUTING: supplierApiUrl+'pc_swiftref/v1/swiftref/national-id/validate?',
	
	// BBAN Validation
	BBAN_VALIDATION: supplierApiUrl+'pc_swiftref/v1/swiftref/IBAN/validate?',
	
	// Swift Validation
	SWIFT_VALIDATION: supplierApiUrl+'pc_swiftref/v1/swiftref/BIC/validate?',
	SWIFT_GET_BANK_NAME: supplierApiUrl+'pc_swiftref/v1/swiftref/national-id/details?',
	RISK_LEVEL: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/CalcRisk/',
	
	NOTFICATION_API: supplierApiUrl+'pc-access-control/users/#userId#/notifications/',
	GET_NOTFICATION_DILIVERY_TYPE: supplierApiUrl+'pc-access-control/notifications/delivery_types',
    GET_NOTFICATION_INTERVALS_TYPES: supplierApiUrl+'pc-access-control/notifications/intervals',
	//Account No. Validation
	AC_NUMBER_VALIDATION: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/AccountNumberFormatValidation/',
	
	//LocalRoutingFormatValidation 
	LOCALROUTING_FORMAT_VALIDATION: supplierApiUrl+'openl-ws/REST/1.0/Supplier/Supplier/LocalRoutingFormatValidation/',
	
	ENTITY_VERIFICATION: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/entity_verification/',
	ENTITY_VERIFICATION_SOURCES: supplierApiUrl +'pc-reference-data/entity_verification_sources/',
    NEGATIVE_NEWS_CATEGORIES: supplierApiUrl +'pc-reference-data/negative_news_categories/',
    METHODS_OF_DELIVERY: supplierApiUrl +'pc-reference-data/methods_of_delivery/',
    WATCHLIST_SCREENING: supplierApiUrl+'pc-request/requests/#requestId#/addresses/',
    ADVERSE_MEDIA_RESEARCH: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/entity_media_research/',
    BANK_SCREENING: supplierApiUrl+'pc-request/requests/#requestId#/banks/',
    OWNER_OFFICER: supplierApiUrl+'pc-request/requests/#requestId#/owners_and_officers/',
    OWNER_OFFICER_ADVERSE_MEDIA: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/owner_media_research/',
    SPIRIT_LETTER: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/spirit_and_letter/',
    REFERENCE: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/references/',
    ACCOUNT_FLAG: supplierApiUrl+'pc-request/requests/#requestId#/due_diligence/overall_info/',
	LIST_TASKS : supplierApiUrl +'pc-workflow/task/supplier/onboarding',
	LIST_TASKS_NEW : supplierApiUrl +'pc-onboarding-util/v1/workflowParser',
	ENTITY_RULE: supplierApiUrl +'openl-ws/REST/1.0/Supplier/Supplier/WorkflowRule/',
    RUN_WATCHLIST: supplierApiUrl +'pc-watch-list/watchlist/individual/check/',
    Admin_URL: supplierApiUrl + 'pc-admin-ui/',
	MyData_URL: supplierApiUrl + 'myData/',
    myData_list: supplierApiUrl + 'pc-search/search/advanced',
    TAGS:supplierApiUrl+'pc-partymaster/tags?pageSize=100',
    //Reporting
    GET_REQUEST_OVERALL_STATUS:supplierApiUrl+'pc-reporting-backend/summary/requests/overall',
    GET_REQUEST_APPROVING_STATUS:supplierApiUrl+'pc-reporting-backend/summary/requests/approvingStatus',
	GET_REQUEST_INVITATION_STATUS:supplierApiUrl+'pc-reporting-backend/summary/requests/invitationStatus',
    GET_TASKS_COMPLETION:supplierApiUrl+'pc-reporting-backend/summary/tasks/completion',
    GET_SELF_SERVE_CYCLE_TIME:supplierApiUrl+'pc-reporting-backend/summary/pages/selfserv',
    GET_COMPLIANCE_PAYMENTS:supplierApiUrl+'pc-reporting-backend/summary/requests/compliancePayment',
    //LOGOUT
    //LOGOUT_URL :'https://pc-api-gateway-dev.run.asv-pr.ice.predix.io/logout',
    //Roles Part
    SUPPLIER_ROLE: "Supplier"
  }
})());
